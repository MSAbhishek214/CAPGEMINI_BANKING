package com.capgemini.banking.exceptions;

public class NoSuchAccountException extends Exception {

	private static final long serialVersionUID = 1L;

	public NoSuchAccountException(String message) {
		super(message);
	}
	
	@Override
	public String getMessage() {
		return super.getMessage() + "Account number does not exist!";
	}
}
