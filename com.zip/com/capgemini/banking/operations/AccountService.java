package com.capgemini.banking.operations;

import com.capgemini.banking.beans.Account;

public interface AccountService {

	public abstract void createAccount(Account account);

	public abstract void showBalance(int accountNumber);

	public abstract void deposit(double amt, int accountNumber);

	public abstract double withdraw(double amt, int accountNumber);

}
