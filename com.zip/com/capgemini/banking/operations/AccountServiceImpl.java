package com.capgemini.banking.operations;

import java.util.ArrayList;
import com.capgemini.banking.beans.Account;
import com.capgemini.banking.exceptions.NoSuchAccountException;

public class AccountServiceImpl implements AccountService, AdvancedBankOperations {

	ArrayList<Account> accountList = new ArrayList<Account>();

	@Override
	public void FundTransfer(int accountNumber1, int accountNumber2, double transferAmount) {
		System.out.println("Amount transferred from " + accountNumber1 + " -------->" + accountNumber2);
		for (Account bankaccount : accountList) {
			if (bankaccount.getAccountNumber() == accountNumber2) {
				bankaccount.getTransactions().setBalance(bankaccount.getTransactions().getBalance() + transferAmount);
			}

		}

		for (Account bankaccount : accountList) {
			if (bankaccount.getAccountNumber() == accountNumber2) {
				bankaccount.getTransactions().setBalance(bankaccount.getTransactions().getBalance() - transferAmount);
			}
		}
	}

	@Override
	public void PrintTransaction() {
		// TODO Auto-generated method stub

	}

	@Override
	public void createAccount(Account account) {
		accountList.add(account);
		System.out.println(account);
	}

	@Override
	public void showBalance(int accountNumber) {
		boolean flag = false;
		for (Account bankaccount : accountList) {
			if (bankaccount.getAccountNumber() == accountNumber) {
				System.out.println("Balance is:" + bankaccount.getTransactions().getBalance());
				flag = true;
				break;
			}
		}
		if (flag == false)
			System.out.println("Invalid Account Number");
	}

	@Override
	public void deposit(double depositAmount, int accountNumber) {
		boolean flag = false;
		for (Account bankaccount : accountList) {
			if (bankaccount.getAccountNumber() == accountNumber) {
				double amount = bankaccount.getTransactions().getBalance() + depositAmount;
				System.out.println("Balance deposited is:" + depositAmount);
				bankaccount.getTransactions().setBalance(amount);
				flag = true;
				break;
			}

		}
		if (flag == false)
			try {
				throw new NoSuchAccountException("AccountNumber" + accountNumber);
			} catch (NoSuchAccountException e) {
				e.printStackTrace();
			}
	}

	@Override
	public double withdraw(double withdrawalAmount, int accountNumber) {
		boolean flag = false;
		try {
			for (Account bankaccount : accountList) {
				if (bankaccount.getAccountNumber() == accountNumber) {
					double amount = bankaccount.getTransactions().getBalance() - withdrawalAmount;
					bankaccount.getTransactions().setBalance(amount);
					flag = true;
					break;
				}
			}
			if (flag == false)
				throw new NoSuchAccountException("AccountNumber" + accountNumber);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return withdrawalAmount;
	}

}
