package com.capgemini.banking.operations;

public interface AdvancedBankOperations {

	public abstract void FundTransfer(int accountNumber1, int accountNumber2, double balance);

	public abstract void PrintTransaction();
}
