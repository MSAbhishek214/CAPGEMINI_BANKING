package com.capgemini.banking.beans;

public class Transaction {

	private double balance;

	public Transaction() {
		super();
		setBalance(balance);
		
	}

	public Transaction(double balance) {
		super();
		setBalance(balance);
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Transaction [balance=" + balance + "]";
	}	
}
