package com.capgemini.banking.beans;

public class Account {

	private static int ACCOUNT_NUMBER_GENERATOR = 101;
	private int accountNumber;
	private String accountType;
	private Transaction transactions;
	private Customer customer;
	
	public Account() {
		super();
		setAccountNumber();
		setAccountType(accountType);
		setTransactions(transactions);
		setCustomer(customer);
	}
	
	public Account(String accountType, Transaction transactions, Customer customer) {
		super();
		setAccountNumber();
		setAccountType(accountType);
		setTransactions(transactions);
		setCustomer(customer);
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber() {
		this.accountNumber = ACCOUNT_NUMBER_GENERATOR++;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Transaction getTransactions() {
		return transactions;
	}

	public void setTransactions(Transaction transactions) {
		this.transactions = transactions;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountType=" + accountType 
				+ ", transactions=" + transactions + ", customer=" + customer + "]";
	}

	
}
