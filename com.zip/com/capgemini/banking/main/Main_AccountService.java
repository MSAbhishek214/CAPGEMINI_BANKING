package com.capgemini.banking.main;

import java.util.Scanner;
import com.capgemini.banking.beans.Account;
import com.capgemini.banking.beans.Address;
import com.capgemini.banking.beans.Customer;
import com.capgemini.banking.beans.Transaction;
import com.capgemini.banking.operations.AccountServiceImpl;

public class Main_AccountService {

	public static void main(String[] args) {
		AccountServiceImpl bankOp = new AccountServiceImpl();
		Address address = null;
		Customer customer = null;
		Account account = null;
		Transaction transactions = null;
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Welcome to bank");
			System.out.println("1 Create Account");
			System.out.println("2 Show Balance");
			System.out.println("3 Deposit Amount");
			System.out.println("4 Withdraw Amount");
			System.out.println("5 Fund Transfer");
			System.out.println("6 Exit");
			System.out.println("Enter choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				try {
					String flatNumber, city, street, pinCode, firstName, lastName, phoneNumber, email, panNumber;
					String customerId, accountType;
					double balance;
					System.out.println("Enter account type");
					accountType = sc.next();
					System.out.println("Enter customerId");
					customerId = sc.next();
					System.out.println("Enter your firstname: ");
					firstName = sc.next();
					System.out.println("Enter your lastname: ");
					lastName = sc.next();
					System.out.println("Enter your phone, email, pan number");
					phoneNumber = sc.next();
					email = sc.next();
					panNumber = sc.next();
					System.out.println("Enter flat number, street, city, pincode");
					flatNumber = sc.next();
					street = sc.next();
					city = sc.next();
					pinCode = sc.next();
					System.out.println("Enter balance");
					balance = sc.nextDouble();
					transactions = new Transaction(balance);
					address = new Address(flatNumber, street, city, pinCode);
					customer = new Customer(customerId, firstName, lastName, 
							phoneNumber, email, panNumber, address);
					account = new Account(accountType, transactions, customer);
					bankOp.createAccount(account); 
					System.out.println("\t\t::Account is created");
				} catch (Exception e) {
					System.out.println(e.getMessage());
					System.out.println("\t\t::Account cannot be created");
				}
				break;
			case 2:
				System.out.println("Enter your accountno: ");
				int accountNo1 = sc.nextInt();
				bankOp.showBalance(accountNo1);
				break;
			case 3:
				System.out.println("Enter your accountno: ");
				int accountNo2 = sc.nextInt();
				System.out.println("Enter amount");
				int amount = sc.nextInt();
				bankOp.deposit(amount, accountNo2);
				break;
			case 4:
				System.out.println("Enter your accountno: ");
				int accNo = sc.nextInt();
				System.out.println("Enter amount");
				int amt = sc.nextInt();
				double balance = bankOp.withdraw(amt, accNo);
				System.out.println("Amount withdrawn: " + balance);
				break;
			case 5:
				System.out.println("Enter your account1: ");
				int accoNo1 = sc.nextInt();
				System.out.println("Enter your account2: ");
				int accoNo2 = sc.nextInt();
				System.out.println("Enter amount");
				double amount1 = sc.nextInt();
				bankOp.FundTransfer(accoNo1, accoNo2, amount1);
			}
		} while (choice != 6);
		sc.close();
	}

}
